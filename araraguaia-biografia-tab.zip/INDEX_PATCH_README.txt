<!-- PATCH: add 'Biografia' to the nav in index.html
<nav class="nav">
  <a href="index.html#edital-cultural">Edital Cultural</a>
  <a href="portfolio.html">Portfólio</a>
  <a href="biografia.html">Biografia</a>
  <a href="https://wa.me/5566996849055?text=Ol%C3%A1!%20Quero%20falar%20com%20a%20Araraguaia%20Produ%C3%A7%C3%B5es." target="_blank">WhatsApp</a>
  <a href="https://instagram.com/araraguaia" target="_blank">Instagram</a>
</nav>
-->